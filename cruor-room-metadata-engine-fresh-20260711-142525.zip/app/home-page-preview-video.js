export function initializeHomePagePreviewVideos() {
  return () => {};
}
