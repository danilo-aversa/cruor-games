import { ComposerRail } from "../../../../components/ui/composer-rail.jsx";
import { LEVEL_VIEW_ALL } from "../../map-generator/map-generator.state.js";
import {
  LOCATION_MAP_EXPORT_CROPS,
  LOCATION_MAP_EXPORT_FORMATS,
  LOCATION_MAP_EXPORT_PADDING,
  LOCATION_MAP_EXPORT_PNG_SCALES,
  LOCATION_MAP_EXPORT_PRESETS,
  getAvailableLocationMapExportLevels,
} from "../model/location-map-export.js";

function cx(...classes) {
  return classes.filter(Boolean).join(" ");
}

function formatLevel(value) {
  const level = Number(value);
  if (!Number.isFinite(level) || level === 0) return "Ground · 0";
  return level > 0 ? `Above · +${level}` : `Below · ${level}`;
}

function SettingToggle({ checked, label, onChange }) {
  return (
    <label className="location-map-export-toggle">
      <input
        type="checkbox"
        checked={Boolean(checked)}
        onChange={(event) => onChange(event.target.checked)}
      />
      <span>{label}</span>
    </label>
  );
}

function SettingSelect({ label, value, onChange, children, disabled = false }) {
  return (
    <label className="location-map-export-field">
      <span>{label}</span>
      <select value={value} onChange={(event) => onChange(event.target.value)} disabled={disabled}>
        {children}
      </select>
    </label>
  );
}

export function LocationMapExportStudio({
  busy = false,
  generatedMap,
  onChange,
  onClose,
  onDownload,
  onPreset,
  settings,
  status = "",
}) {
  const levels = getAvailableLocationMapExportLevels(generatedMap);
  const format = settings?.format || "svg";

  return (
    <ComposerRail
      side="right"
      variant="controls"
      surface
      scrollable
      className="location-map-export-studio cruor-composer-rail location-composer__rail location-composer__rail--right"
      aria-label="Map export settings"
    >
      <section className="cruor-composer-rail-card cruor-composer-rail-card--hero location-map-export-studio__hero">
        <div>
          <span className="cruor-composer-rail-card__eyebrow">Download</span>
          <strong>Map Export</strong>
        </div>
        <button
          className="location-output-icon-action"
          type="button"
          aria-label="Close map export settings"
          onClick={onClose}
        >
          <i className="fa-solid fa-xmark" aria-hidden="true" />
        </button>
      </section>

      <section className="cruor-composer-rail-card location-map-export-card">
        <span className="location-map-export-card__label">Preset</span>
        <div className="location-map-export-presets" role="group" aria-label="Map export preset">
          {LOCATION_MAP_EXPORT_PRESETS.map((preset) => (
            <button
              className={cx("cruor-composer-control", settings?.preset === preset.id && "is-active")}
              type="button"
              key={preset.id}
              aria-pressed={settings?.preset === preset.id}
              title={preset.description}
              onClick={() => onPreset?.(preset.id)}
            >
              {preset.label}
            </button>
          ))}
        </div>
      </section>

      <section className="cruor-composer-rail-card location-map-export-card">
        <span className="location-map-export-card__label">File</span>
        <div className="location-map-export-fields">
          <SettingSelect label="Format" value={format} onChange={(value) => onChange?.({ format: value })}>
            {LOCATION_MAP_EXPORT_FORMATS.map((option) => (
              <option value={option.id} key={option.id}>{option.label}</option>
            ))}
          </SettingSelect>
          <SettingSelect
            label="Resolution"
            value={String(settings?.pngScale || 2)}
            disabled={format !== "png"}
            onChange={(value) => onChange?.({ pngScale: Number(value) })}
          >
            {LOCATION_MAP_EXPORT_PNG_SCALES.map((option) => (
              <option value={String(option.id)} key={option.id}>{option.label}</option>
            ))}
          </SettingSelect>
        </div>
      </section>

      <section className="cruor-composer-rail-card location-map-export-card">
        <span className="location-map-export-card__label">Area</span>
        <div className="location-map-export-fields">
          <SettingSelect label="Crop" value={settings?.crop || "content"} onChange={(value) => onChange?.({ crop: value })}>
            {LOCATION_MAP_EXPORT_CROPS.map((option) => (
              <option value={option.id} key={option.id}>{option.label}</option>
            ))}
          </SettingSelect>
          <SettingSelect
            label="Padding"
            value={String(settings?.padding ?? 48)}
            disabled={settings?.crop === "canvas"}
            onChange={(value) => onChange?.({ padding: Number(value) })}
          >
            {LOCATION_MAP_EXPORT_PADDING.map((option) => (
              <option value={String(option.id)} key={option.id}>{option.label}</option>
            ))}
          </SettingSelect>
          <SettingSelect label="Level" value={String(settings?.levelView ?? LEVEL_VIEW_ALL)} onChange={(value) => onChange?.({ levelView: value === LEVEL_VIEW_ALL ? LEVEL_VIEW_ALL : Number(value) })}>
            <option value={LEVEL_VIEW_ALL}>All Levels</option>
            {levels.map((level) => (
              <option value={String(level)} key={level}>{formatLevel(level)}</option>
            ))}
          </SettingSelect>
        </div>
      </section>

      <section className="cruor-composer-rail-card location-map-export-card">
        <span className="location-map-export-card__label">Map Layers</span>
        <div className="location-map-export-toggle-list">
          <SettingToggle checked={settings?.showGrid} label="Grid" onChange={(value) => onChange?.({ showGrid: value })} />
          <SettingToggle checked={settings?.showRoomNumbers} label="Room numbers" onChange={(value) => onChange?.({ showRoomNumbers: value })} />
          <SettingToggle checked={settings?.showRoomNames} label="Room names" onChange={(value) => onChange?.({ showRoomNames: value })} />
          <SettingToggle checked={settings?.showProps} label="Props and markers" onChange={(value) => onChange?.({ showProps: value })} />
          <SettingToggle checked={settings?.showStairArrows} label="Stair direction" onChange={(value) => onChange?.({ showStairArrows: value })} />
          <SettingToggle checked={settings?.showHatching} label="External hatching" onChange={(value) => onChange?.({ showHatching: value })} />
          <SettingToggle checked={settings?.showTexture} label="Paper texture" onChange={(value) => onChange?.({ showTexture: value })} />
          <SettingToggle checked={settings?.hideSecrets} label="Hide secret routes" onChange={(value) => onChange?.({ hideSecrets: value })} />
        </div>
      </section>

      <section className="cruor-composer-rail-card location-map-export-card">
        <SettingSelect label="Background" value={settings?.background || "style"} onChange={(value) => onChange?.({ background: value })}>
          <option value="style">Map Style</option>
          <option value="white">White</option>
          <option value="transparent">Transparent</option>
        </SettingSelect>
      </section>

      <section className="location-map-export-studio__footer">
        <button
          className="cruor-composer-control location-map-export-download"
          type="button"
          disabled={busy || !generatedMap}
          onClick={onDownload}
          data-testid="dark-places-map-export-download"
        >
          <i className={`fa-solid ${busy ? "fa-spinner fa-spin" : "fa-download"}`} aria-hidden="true" />
          <span>{busy ? "Preparing" : `Download ${format.toUpperCase()}`}</span>
        </button>
        <span className={cx("location-map-export-status", status && "is-visible")} aria-live="polite">
          {status}
        </span>
      </section>
    </ComposerRail>
  );
}
